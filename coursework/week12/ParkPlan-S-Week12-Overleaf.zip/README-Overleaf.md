# ParkPlan-S: Week 12 modified implementation paper

Data credit: TouringPlans.com supplies the historical Animal Kingdom posted waits and public park-hour listings used in this work.

Authors: Jesse Zhang and Yongqi Sheng.

## Contents and scope

The manuscript contains Abstract, Introduction, Related Work, Methodology (including an explicit Contribution subsection), Evaluation, Conclusion and Future Work, and References. It extends the preserved Week 10 v2 draft with evidence from the frozen October 19 comparison and the separate bounded November 8 ADAPT author-code reproduction. It does not introduce a new performance claim, retune the algorithms, or label previously inspected dates as an untouched test.

The tested park modifications are the historical scenario bank, information-limited base-policy continuation, rollout action scoring, validation-selected decay control, and shared-order scenario ablation. None is established as superior to existing D0. The ADAPT UAV reproduction remains separate from the park experiment. Walking/service sensitivity cases use the same posted-wait records, so they are not modified raw datasets or a controlled same-parent-dataset versus new-dataset benchmark.

## Compile in Overleaf

1. Create a new project with **Upload Project** and upload the source ZIP.
2. Select `main.tex` as the main document and pdfLaTeX as compiler.
3. Recompile through bibliography resolution and download the PDF.
4. Keep the official fonts, margins, column widths and page settings unchanged.

The local build uses Tectonic 0.17.0. Local compilation does not establish actual Overleaf UI compilation.

```bash
env XDG_CACHE_HOME=/tmp/ds340-tectonic-cache \
  /tmp/ds340-tectonic-bin/tectonic --untrusted --only-cached \
  --keep-logs --keep-intermediates main.tex
```

The command assumes that the compiler and all public TeX resources are already cached. A standard installed pdfLaTeX/BibTeX distribution or Overleaf is the portable alternative; temporary compiler/cache paths are not included in the ZIP.

## Template provenance

- Assignment template: https://www.overleaf.com/latex/templates/icml2025-template/dhxrkcgkvnkt
- Official archive: https://media.icml.cc/Conferences/ICML2025/Styles/icml2025.zip
- `template-provenance.json` records the original download and hashes.
- The five official style/bibliography companion files are unchanged.
- The style's `accepted` option displays author names; the manuscript replaces the publication notice with truthful DS 340W coursework metadata. This does not claim ICML acceptance.
- Names-only correspondence avoids inventing contact details or university affiliation.
- OT1 font encoding preserves the template's Times family under Tectonic. Loading `float` before `hyperref` prevents duplicate table/algorithm destinations without modifying official styles.

## Evidence links

Research repository: https://github.com/SPARTAN827/DS340-ParkPlan-S

Frozen park comparison: https://github.com/SPARTAN827/DS340-ParkPlan-S/tree/8ebd20e/experiments/algorithm_study_20261019

Dataset: https://github.com/TouringPlans/DisneyAnimalKingdomWaitTimes

Pinned dataset commit: `933161b8bebb7cd50e0d54bcb3578484875487fa`.

No raw data, private project notes, compiler binaries or caches belong in this manuscript source package. The student's real recording, Kaltura sharing checks and course submission are separate from document preparation. No grade or similarity-detector percentage is claimed.

## TouringPlans data terms

You're free to use these data however you see fit, subject to the following:

1. Any publications or redistributions credit TouringPlans.com clearly at the beginning of those publications or distributions.
2. Any redistributions include these license terms.
